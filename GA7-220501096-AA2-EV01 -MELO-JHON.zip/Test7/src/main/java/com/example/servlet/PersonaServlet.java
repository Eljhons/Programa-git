package com.example.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.example.model.Persona;
import com.example.model.PersonaDAO;
import com.google.gson.Gson;

@WebServlet("/persona")
public class PersonaServlet extends HttpServlet {

    private PersonaDAO personaDAO;

    @Override
    public void init() throws ServletException {
        personaDAO = new PersonaDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<Persona> personas = personaDAO.obtenerTodos();
        String json = new Gson().toJson(personas);

        response.setContentType("application/json");
        response.getWriter().write(json);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Recupera los parámetros del formulario
        String nombre = request.getParameter("name");
        int edad = Integer.parseInt(request.getParameter("age"));

        // Crea una nueva Persona
        Persona nuevaPersona = new Persona(nombre, edad);

        // Agrega la nueva Persona a la base de datos
        personaDAO.agregarPersona(nuevaPersona);

        response.getWriter().write("Persona agregada correctamente");
    }

    @Override
    protected void doPut(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Recupera el ID y los nuevos datos de la persona desde los parámetros de la solicitud
        int id = Integer.parseInt(request.getParameter("id"));
        String nuevoNombre = request.getParameter("name");
        int nuevaEdad = Integer.parseInt(request.getParameter("age"));

        // Obtén la persona existente
        Persona personaExistente = personaDAO.obtenerPorId(id);

        if (personaExistente != null) {
            // Actualiza los datos de la persona existente
            personaExistente.setName(nuevoNombre);
            personaExistente.setAge(nuevaEdad);

            // Actualiza la persona en la base de datos
            personaDAO.actualizarPersona(personaExistente);

            response.getWriter().write("Persona actualizada correctamente");
        } else {
            response.getWriter().write("Persona no encontrada");
        }
    }

    @Override
    protected void doDelete(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Recupera el ID de la persona a eliminar desde los parámetros de la solicitud
        int id = Integer.parseInt(request.getParameter("id"));

        // Elimina la persona de la base de datos
        personaDAO.eliminarPersona(id);

        response.getWriter().write("Persona eliminada correctamente");
    }
}
