<?php
// Mostrar errores y habilitar el modo de desarrollo
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Conexión a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test";
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar errores de conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

$mensaje = "Conexión exitosa a la base de datos: " . $dbname;

// Operación para recuperar todos los registros
if (isset($_GET['retrieve'])) {
    // Sentencia SQL para obtener todos los registros
    $sql = "SELECT * FROM usuario";
    $result = $conn->query($sql);

    if ($result) {
        $records = $result->fetch_all(MYSQLI_ASSOC);

        // Establecer el encabezado para indicar que se envía JSON
        header('Content-Type: application/json');
        echo json_encode($records);
        $conn->close();
        exit();
    } else {
        $mensaje = "Error al recuperar los registros: " . $conn->error;
    }
}

// Operación para insertar un nuevo registro
if (isset($_POST['insert'])) {
    $newName = $_POST['newName'];
    $newAge = $_POST['newAge'];

    // Sentencia preparada para prevenir la inyección SQL
    $stmt = $conn->prepare("INSERT INTO usuario (name, age) VALUES (?, ?)");
    $stmt->bind_param("si", $newName, $newAge);

    if ($stmt->execute()) {
        $mensaje = "Registro insertado con éxito.";
    } else {
        $mensaje = "Error al insertar el registro: " . $stmt->error;
    }

    // Cerrar la conexión
    $stmt->close();
}

// Operación para eliminar un registro
if (isset($_POST['delete'])) {
    $idToDelete = $_POST['idToDelete'];

    // Sentencia preparada para prevenir la inyección SQL
    $stmt = $conn->prepare("DELETE FROM usuario WHERE id = ?");
    $stmt->bind_param("i", $idToDelete);

    if ($stmt->execute()) {
        $mensaje = "Registro eliminado con éxito.";
    } else {
        $mensaje = "Error al eliminar el registro: " . $stmt->error;
    }

    // Cerrar la conexión
    $stmt->close();
}

// Operación para actualizar un registro
if (isset($_POST['update'])) {
    $idToUpdate = $_POST['idToUpdate'];
    $newName = $_POST['newName'];
    $newAge = $_POST['newAge'];

    // Sentencia preparada para prevenir la inyección SQL
    $stmt = $conn->prepare("UPDATE usuario SET name = ?, age = ? WHERE id = ?");
    $stmt->bind_param("sii", $newName, $newAge, $idToUpdate);

    if ($stmt->execute()) {
        $mensaje = "Registro actualizado con éxito.";
    } else {
        $mensaje = "Error al actualizar el registro: " . $stmt->error;
    }

    // Cerrar la conexión
    $stmt->close();
}

// Resto del código PHP...

// Cerrar la conexión
$conn->close();
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Usuarios</title>
    <style>
        /* Estilos CSS aquí */

        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }

        /* Barras Azules Divisorias */
        .divider {
            width: 100%;
            height: 2px;
            background-color: #3498db;
            margin: 10px 0;
        }

        /* Resto de estilos CSS */
    </style>
</head>

<body>
    <!-- Barras Azules Divisorias -->
    <div class="divider"></div>

    <h1><?php echo $mensaje; ?></h1>

    <!-- Formulario de inserción -->
    <form action="" method="post">
        <label for="newName">Nombre:</label>
        <input type="text" name="newName" required>
        <label for="newAge">Edad:</label>
        <input type="number" name="newAge" required>
        <button type="submit" name="insert">Insertar Registro</button>
    </form>

    <!-- Barras Azules Divisorias -->
    <div class="divider"></div>

    <!-- Operaciones CRUD -->

    <div class="crud-buttons">
        <button onclick="location.href='actualizar.php'">Actualizar Registro</button>
        <button onclick="location.href='eliminar.php'">Eliminar Registro</button>
    </div>

    <!-- Formulario de eliminación -->
    <form action="" method="post">
        <label for="idToDelete">ID a eliminar:</label>
        <input type="number" name="idToDelete" required>
        <button type="submit" name="delete">Eliminar Registro</button>
    </form>

    <!-- Formulario de actualización -->
    <form action="" method="post">
        <label for="idToUpdate">ID a actualizar:</label>
        <input type="number" name="idToUpdate" required>
        <label for="newName">Nuevo Nombre:</label>
        <input type="text" name="newName" required>
        <label for="newAge">Nueva Edad:</label>
        <input type="number" name="newAge" required>
        <button type="submit" name="update">Actualizar Registro</button>
    </form>

    <!-- Barras Azules Divisorias -->
    <div class="divider"></div>

    <!-- Botón para consultar datos -->
    <form action="?retrieve=true" method="get">
        <button type="submit" name="retrieve">Consultar Datos</button>
    </form>

    <!-- Barras Azules Divisorias -->
    <div class="divider"></div>

    <!-- Lista de registros -->

    <?php
    // Mostrar la lista si hay registros
    if (isset($records)) {
        echo "<ul>";
        foreach ($records as $record) {
            echo "<li>ID: {$record['id']}, Nombre: {$record['name']}, Edad: {$record['age']}</li>";
        }
        echo "</ul>";
    }
    ?>
</body>

</html>