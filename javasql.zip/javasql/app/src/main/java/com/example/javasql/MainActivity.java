package com.example.javasql;

        import android.os.Bundle;
        import android.util.Log;
        import android.widget.Button;
        import android.widget.EditText;
        import android.widget.TextView;
        import android.widget.Toast;

        import androidx.appcompat.app.AppCompatActivity;

        import com.android.volley.Request;
        import com.android.volley.RequestQueue;
        import com.android.volley.toolbox.StringRequest;
        import com.android.volley.toolbox.Volley;

        import org.json.JSONException;
        import org.json.JSONObject;

        import java.util.HashMap;
        import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private static final String BASE_URL = "http://192.168.56.1:8080/javasql/conexion.php";
    private EditText editTextName, editTextAge, editTextSearchId;
    private Button btnInsert, btnRetrieve, btnUpdate, btnDelete;
    private TextView resultTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicializar vistas
        editTextName = findViewById(R.id.editTextName);
        editTextAge = findViewById(R.id.editTextAge);
        editTextSearchId = findViewById(R.id.editTextSearchId);
        btnInsert = findViewById(R.id.btnInsert);
        btnRetrieve = findViewById(R.id.btnRetrieve);
        btnUpdate = findViewById(R.id.btnUpdate);
        btnDelete = findViewById(R.id.btnDelete);
        resultTextView = findViewById(R.id.resultTextView);

        // Configurar listeners de botones
        btnInsert.setOnClickListener(v -> insertData());
        btnRetrieve.setOnClickListener(v -> retrieveData());
        btnUpdate.setOnClickListener(v -> updateData());
        btnDelete.setOnClickListener(v -> deleteData());
    }

    private void sendHttpRequest(String url, int method, Map<String, String> params, final VolleyResponseListener callback) {
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        StringRequest stringRequest = new StringRequest(method, url,
                response -> callback.onSuccess(response),
                error -> callback.onError(error.getMessage())) {
            @Override
            protected Map<String, String> getParams() {
                return params;
            }
        };
        requestQueue.add(stringRequest);
    }

    private void insertData() {
        final String name = editTextName.getText().toString();
        final String ageStr = editTextAge.getText().toString();

        if (name.isEmpty() || ageStr.isEmpty()) {
            showToast("Por favor, complete todos los campos.");
            return;
        }

        Map<String, String> params = new HashMap<>();
        params.put("newName", name);
        params.put("newAge", ageStr);
        params.put("insert", "true");

        sendHttpRequest(BASE_URL, Request.Method.POST, params, new VolleyResponseListener() {
            @Override
            public void onSuccess(String response) {
                Log.d("InsertData", "Response: " + response);
                Log.d("Debug", response);

                try {
                    JSONObject jsonResponse = new JSONObject(response);
                    boolean success = jsonResponse.getBoolean("success");

                    if (success) {
                        String doctipe = jsonResponse.optString("doctipe", "");
                        showToast("Registro insertado con éxito. ID: " + doctipe);
                    } else {
                        showToast("Error al insertar el registro.");
                    }
                } catch (JSONException e) {
                    showToast("Error JSON: " + e.getMessage());
                    Log.e("Debug", "Error al convertir la respuesta a JSON", e);

                }
            }

            @Override
            public void onError(String errorMessage) {
                showToast("Error: " + errorMessage);
            }
        });
    }

    private void retrieveData() {
        String url = BASE_URL + "?retrieve=true";

        sendHttpRequest(url, Request.Method.GET, new HashMap<>(), new VolleyResponseListener() {
            @Override
            public void onSuccess(String response) {

                Log.d("RetrieveData", "Response: " + response);

                resultTextView.setText(response);
            }

            @Override
            public void onError(String errorMessage) {
                showToast("Error: " + errorMessage);
            }
        });
    }

    private void updateData() {
        final String id = editTextSearchId.getText().toString();
        final String newName = editTextName.getText().toString();
        final String newAge = editTextAge.getText().toString();

        if (id.isEmpty() || newName.isEmpty() || newAge.isEmpty()) {
            showToast("Por favor, complete todos los campos.");
            return;
        }

        Map<String, String> params = new HashMap<>();
        params.put("id", id);
        params.put("newName", newName);
        params.put("newAge", newAge);
        params.put("update", "true");

        sendHttpRequest(BASE_URL, Request.Method.POST, params, new VolleyResponseListener() {
            @Override
            public void onSuccess(String response) {
                try {
                    JSONObject jsonResponse = new JSONObject(response);
                    boolean success = jsonResponse.getBoolean("success");

                    if (success) {
                        showToast("Registro actualizado con éxito.");
                    } else {
                        showToast("Error al actualizar el registro.");
                    }
                } catch (JSONException e) {
                    showToast("Error JSON: " + e.getMessage());
                }
            }

            @Override
            public void onError(String errorMessage) {
                showToast("Error: " + errorMessage);
            }
        });
    }

    private void deleteData() {
        final String id = editTextSearchId.getText().toString();

        if (id.isEmpty()) {
            showToast("Por favor, complete todos los campos.");
            return;
        }

        Map<String, String> params = new HashMap<>();
        params.put("idToDelete", id);
        params.put("delete", "true");

        sendHttpRequest(BASE_URL, Request.Method.POST, params, new VolleyResponseListener() {
            @Override
            public void onSuccess(String response) {
                try {
                    JSONObject jsonResponse = new JSONObject(response);
                    boolean success = jsonResponse.getBoolean("success");

                    if (success) {
                        showToast("Registro eliminado con éxito.");
                    } else {
                        showToast("Error al eliminar el registro.");
                    }
                } catch (JSONException e) {
                    showToast("Error JSON: " + e.getMessage());
                }
            }

            @Override
            public void onError(String errorMessage) {
                showToast("Error: " + errorMessage);
            }
        });
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}

interface VolleyResponseListener {
    void onSuccess(String response);
    void onError(String errorMessage);
}
