<?php
// Conexión a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test";

$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

// Determinar la operación a realizar (insertar, actualizar, recuperar o eliminar)
$operacion = $_POST['operacion'];

if ($operacion === 'insertar') {
    // Operación para insertar datos en la base de datos
    $columna1 = $_POST['columna1'];
    $columna2 = $_POST['columna2'];
    
    $sql = "INSERT INTO usuario (columna1, columna2) VALUES ('$columna1', '$columna2')";
    
    if ($conn->query($sql) === TRUE) {
        echo "Inserción exitosa";
    } else {
        echo "Error en la inserción: " . $conn->error;
    }
} elseif ($operacion === 'actualizar') {
    // Operación para actualizar datos en la base de datos
    $id = $_POST['id'];
    $nuevoValorColumna1 = $_POST['nuevo_valor_columna1'];
    $nuevoValorColumna2 = $_POST['nuevo_valor_columna2'];
    
    $sql = "UPDATE usuario SET columna1 = '$nuevoValorColumna1', columna2 = '$nuevoValorColumna2' WHERE id = $id";
    
    if ($conn->query($sql) === TRUE) {
        echo "Actualización exitosa";
    } else {
        echo "Error en la actualización: " . $conn->error;
    }
} elseif ($operacion === 'recuperar') {
    // Operación para recuperar datos de la base de datos
    $sql = "SELECT * FROM usuario";
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        $data = array();
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
        echo json_encode($data);
    } else {
        echo "No se encontraron registros.";
    }
} elseif ($operacion === 'eliminar') {
    // Operación para eliminar datos de la base de datos
    $id = $_POST['id'];
    
    $sql = "DELETE FROM usuario WHERE id = $id";
    
    if ($conn->query($sql) === TRUE) {
        echo "Eliminación exitosa";
    } else {
        echo "Error en la eliminación: " . $conn->error;
    }
} else {
    echo "Operación no válida.";
}

// Cerrar la conexión
$conn->close();
?>