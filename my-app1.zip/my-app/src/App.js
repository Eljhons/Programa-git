import React, { useState, useEffect } from 'react';
import './App.css';

function obtenerDatosDeLaBaseDeDatos() {
  // Hacer la llamada a la API o servidor para obtener datos reales
  // Por ahora, usaremos datos de ejemplo
  return [
    { id: 1, name: 'John', age: 25, date: '2023-10-25' },
    { id: 2, name: 'Jane', age: 30, date: '2023-10-26' },
    // Agregar más datos según sea necesario
  ];
}

function App() {
  const [datosMostrados, setDatosMostrados] = useState([]);
  const [mostrarDatos, setMostrarDatos] = useState(false);
  const [nuevoNombre, setNuevoNombre] = useState('');
  const [nuevaEdad, setNuevaEdad] = useState('');
  const [fechaActual, setFechaActual] = useState('');

  useEffect(() => {
    // Actualizar la fecha actual en tiempo real
    const intervalId = setInterval(() => {
      const nuevaFecha = new Date().toLocaleDateString();
      setFechaActual(nuevaFecha);
    }, 1000); // Actualizar cada segundo

    return () => clearInterval(intervalId); // Limpiar el intervalo al desmontar el componente
  }, []); // El segundo argumento [] asegura que useEffect se ejecute solo una vez al montar el componente

  const toggleMostrarDatos = () => {
    if (mostrarDatos) {
      setDatosMostrados([]);
    } else {
      const datos = obtenerDatosDeLaBaseDeDatos();
      setDatosMostrados(datos);
    }
    setMostrarDatos(!mostrarDatos);
  };

  const agregarRegistro = () => {
    const nuevoRegistro = {
      id: datosMostrados.length + 1,
      name: nuevoNombre,
      age: nuevaEdad,
      date: fechaActual,
    };

    setDatosMostrados([...datosMostrados, nuevoRegistro]);

    setNuevoNombre('');
    setNuevaEdad('');
  };

  const eliminarRegistro = (id) => {
    const nuevosDatos = datosMostrados.filter((dato) => dato.id !== id);
    setDatosMostrados(nuevosDatos);
  };

  return (
    <div className={`App ${mostrarDatos ? 'active' : ''}`}>
      <header className="App-header">
        <p>Programa Reactjs <code>Bienvenido.</code></p>
        <button className="toggle-button" onClick={toggleMostrarDatos}>
          {mostrarDatos ? 'Ocultar Datos' : 'Consultar Datos'}
        </button>
        {mostrarDatos && (
          <div className="data-form">
            <form>
              <label>
                Nombre:
                <input
                  type="text"
                  value={nuevoNombre}
                  onChange={(e) => setNuevoNombre(e.target.value)}
                />
              </label>
              <label>
                Edad:
                <input
                  type="text"
                  value={nuevaEdad}
                  onChange={(e) => setNuevaEdad(e.target.value)}
                />
              </label>
              <label>
                Fecha Actual:
                <input
                  type="text"
                  value={fechaActual}
                  readOnly
                />
              </label>
              <button type="button" onClick={agregarRegistro}>
                Agregar Registro
              </button>
            </form>

            <table className="data-table">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Nombre</th>
                  <th>Edad</th>
                  <th>Fecha</th>
                  <th>Acciones</th>
                </tr>
              </thead>
              <tbody>
                {datosMostrados.map((dato) => (
                  <tr key={dato.id}>
                    <td>{dato.id}</td>
                    <td>{dato.name}</td>
                    <td>{dato.age}</td>
                    <td>{dato.date}</td>
                    <td>
                      <button className="delete-button" onClick={() => eliminarRegistro(dato.id)}>
                        Eliminar
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </header>
    </div>
  );
}

export default App;
